# FS57 v0.2.0 — focused mathematical preprint

- Revised title, abstract, introduction, and conclusion focusing on the explicit 57-degree eight-branch fractal deformation of the Spectre skeleton.
- Complete mathematical argument retained, including finite geometry, embedding rigidity, B-adic alignment, local winding cancellation, angle-word descent, and tiling equivalence.
- Only the model-generated illustration is distributed. Historical working materials are retained separately.
- Four unchanged verification scripts with reference outputs; self-contained replay and source-file hash provenance.
- Updated citation and Zenodo metadata.

Status: internally audited computer-assisted proof candidate awaiting independent specialist review. No priority claim.
