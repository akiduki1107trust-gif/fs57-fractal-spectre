# Zenodo metadata — v0.2.0

**Title:** FS57: A Fractal-Boundary Deformation of the Spectre Tile: A computer-assisted proof candidate for forced aperiodicity

**Resource type:** Publication → Preprint  
**Creator:** Harada, Shigehisa  
**Affiliation:** Independent Researcher  
**Version:** 0.2.0  
**Language:** English  
**Publication date:** Actual deposit date (manuscript dated 2026-11-21)  
**ORCID:** only if verified and provided by author  
**License:** Select after author review (e.g. CC BY 4.0 for manuscript; MIT for separately licensed author-owned code).  
**DOI:** Not yet assigned.  
**Access:** Public after author approval.

## Description

We study a specific fourteen-edge deformation of the marked equilateral polygon Tile(1,1) using an eight-branch self-similar Jordan arc at 57 degrees, of Hausdorff dimension approximately 1.14187. We present an internally audited computer-assisted proof candidate for strong aperiodicity, including when reflected copies are permitted. The proposed reduction combines rigorous finite geometric and residual certificates, natural Hausdorff-measure parametrization, B-adic alignment, local winding-number cancellation, and a four-child angle-word descent to establish placement-preserving equivalence with homochiral Tile(1,1) tilings. The published Spectre theorem supplies the final existence and aperiodicity result if the reduction is valid. Four certificate scripts and byte-matching reference outputs are provided. The full proof has not been formally verified or independently refereed; no claim of priority is made.

## Keywords

aperiodic monotile; Spectre; fractal boundary; self-similar Jordan arc; computer-assisted proof; B-adic alignment; winding number

## Related identifier

DOI `10.5070/C64264241` — References (published Spectre theorem).

## Upload

- `FS57_preprint_v0.2.0.pdf`
- `FS57_GitHub_Zenodo_v0.2.0.zip`

Attach both in the same preprint record. If a previous version is already deposited, use Zenodo's New version function rather than creating an unrelated duplicate. After publishing, cross-link the actual repository/release URL and DOI.
