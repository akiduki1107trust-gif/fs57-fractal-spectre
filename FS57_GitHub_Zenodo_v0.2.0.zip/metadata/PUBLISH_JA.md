# GitHub・Zenodo投稿手順（v0.2.0）

## 公開前確認

本文・著者名・引用・AI支援表示を確認し、公開許可とライセンスを決定する。論文・図 CC BY 4.0、著者所有コード MIT は候補であり、未承認のライセンスは付与していない。査読済み・世界初とは記載しない。ORCIDは本人確認済みの番号のみ。

## GitHub

1. https://github.com/new （既存リポジトリがある場合はそちらを使用）。推奨名 `fs57-fractal-spectre`（空き状況は未確認）。
2. ZIPを展開してルートにある全ファイルをアップロード。隠しファイル `.zenodo.json` も含める。旧版が存在する場合は改訂版として更新し、旧版の不要な添付物が公開履歴に残る点に注意する。
3. `README.md` と `paper/FS57.pdf` の表示を確認し、可能なら `python code/verify.py` で検算する。
4. Releases → Draft a new release、タグ `v0.2.0`、タイトル `FS57 v0.2.0 — Fractal-boundary Spectre preprint`。リリース説明は `metadata/RELEASE_NOTES.md` を使用する。

## Zenodo

1. https://zenodo.org/ にログインし、新規投稿を作成する（既に旧版を公開している場合は New version）。
2. `FS57_preprint_v0.2.0.pdf` と `FS57_GitHub_Zenodo_v0.2.0.zip` を同じ投稿に添付する。
3. Resource type は Publication → Preprint。タイトル、著者、概要、キーワードは `metadata/ZENODO_METADATA.md` を使用。
4. 公開日、ライセンス、アクセス設定を確認。実際のGitHub URLを関連識別子に追加できる。DOIの予約が必要な場合はZenodo内で行う。
5. プレビューを確認後、本人が Publish。DOIが割り当てられたらREADMEとCITATIONに追加する。自動アーカイブと手動投稿の重複登録に注意。

公開は第三者査読完了を意味しない。現状は内部計算機援用完全証明候補である。
