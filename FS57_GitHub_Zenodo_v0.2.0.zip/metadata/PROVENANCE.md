# Certificate provenance

The four certificate scripts and their JSON reference outputs are copied byte for byte from the pre-existing CP717–722 and CP716 checkpoint archives. During preparation each of the eight files was compared with its archived source. The parent CP717–722 ZIP SHA-256 was verified as `7b9193fefbe25e09d13605b25d3d91afba26f63184ff79e6ed40ea34c0148b56`.

- `CP711_exact_kernel.py` and `CP712_macro_exact.py` and their JSONs: CP716 nested archive inside CP717–722.
- `cp718_b_adic_audit.py` and `cp720_hull_audit.py` and their JSONs: CP717–722 outer archive.

The historical checkpoint archives are retained separately, not redistributed in this release. The eight source/reference hashes are recorded in `CERTIFICATE_SHA256.txt`; the new wrapper verifies them before running. The archived originals are not altered. The public release is self-contained and includes no unrelated research material.
