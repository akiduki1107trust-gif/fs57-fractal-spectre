# Rights and licensing — review before publication

The manuscript, generated model illustration, and research scripts are prepared for Shigehisa Harada with AI assistance. The author must approve attribution, redistribution and license choice. Suggested licenses: CC BY 4.0 for research text and figures; MIT for author-owned code. No license is automatically granted by this preparation. Third-party published mathematical results are cited and are not relicensed here. No DOI, registration or external endorsement is implied.
