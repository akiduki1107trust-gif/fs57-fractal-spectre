#!/usr/bin/env python3
"""Verify source hashes, replay all four finite certificates, and compare output bytes."""
from pathlib import Path
import hashlib, shutil, subprocess, sys, tempfile
if not __debug__:
    raise SystemExit("Run without -O: certificates use assert.")
ROOT = Path(__file__).resolve().parents[1]
NAMES = ('CP711_exact_kernel', 'CP712_macro_exact', 'cp718_b_adic_audit', 'cp720_hull_audit')
for line in (ROOT/'metadata/CERTIFICATE_SHA256.txt').read_text().splitlines():
    digest, filename = line.split(maxsplit=1)
    assert hashlib.sha256((ROOT/filename).read_bytes()).hexdigest() == digest, filename
print('Eight source/reference hashes: PASS', flush=True)
with tempfile.TemporaryDirectory(prefix='fs57_verify_') as work:
    tmp = Path(work)
    for name in NAMES:
        script = tmp / f'{name}.py'
        shutil.copyfile(ROOT/'code'/script.name, script)
        subprocess.run([sys.executable, str(script)], cwd=tmp, check=True)
        assert script.with_suffix('.json').read_bytes() == (ROOT/'results'/f'{name}.json').read_bytes(), name
        print(f'{name}: byte-identical JSON PASS', flush=True)
print('ALL FOUR FINITE CERTIFICATE REPLAYS PASS; analytic proof is not formally verified.')
