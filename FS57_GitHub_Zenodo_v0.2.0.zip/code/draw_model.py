#!/usr/bin/env python3
"""Illustrative finite-level approximations; NOT proof certificates. Requires matplotlib."""
import cmath, math
from pathlib import Path
import matplotlib.pyplot as plt
q=cmath.exp(19j*math.pi/60); s=1/(4*(1+q.real)); e=(0,1,-1,0,0,-1,1,0)
a=[s*q**j for j in e]; p=[0j]
for z in a:p.append(p[-1]+z)
p[-1]=1+0j
def arc(n):
    pts=[0j,1+0j]
    for _ in range(n):pts=[p[j]+a[j]*z for j in range(8) for z in pts[:-1]]+[1+0j]
    return pts
D=(0,10,1,3,0,2,5,7,4,6,6,8,11,9); w=cmath.exp(1j*math.pi/6); V=[0j]
for j in D:V.append(V[-1]+w**j)
V[-1]=0j
K=arc(3); P=[V[i]+w**j*z for i,j in enumerate(D) for z in K[:-1]]+[0j]
fig,axs=plt.subplots(1,2,figsize=(9,4.2),gridspec_kw={'width_ratios':[1,1.15]})
ax=axs[0]; v=arc(1); ax.plot([z.real for z in v],[z.imag for z in v],lw=1.8,color='#175b85',marker='o',ms=3); ax.axhline(0,color='#929da3',lw=.7,ls='--'); ax.set_title('Eight-branch generator (57°)'); ax.set_aspect('equal'); ax.set_xlabel('Re z'); ax.set_ylabel('Im z'); ax.spines[['top','right']].set_visible(False)
ax=axs[1]; ax.fill([z.real for z in P],[z.imag for z in P],color='#dbeaf1'); ax.plot([z.real for z in P],[z.imag for z in P],color='#175b85',lw=.6); ax.plot([z.real for z in V],[z.imag for z in V],color='#7b8790',lw=.75,ls='--'); ax.set_aspect('equal'); ax.set_title('14-edge tile, depth 3'); ax.axis('off'); fig.tight_layout(); fig.savefig(Path(__file__).resolve().parents[1]/'figures/model.pdf',bbox_inches='tight'); fig.savefig(Path(__file__).resolve().parents[1]/'figures/model.png',dpi=180,bbox_inches='tight'); plt.close(fig)
