#!/usr/bin/env python3
"""Exact interval convex hull certificate for P; uniform 0.135<h<0.136."""
from fractions import Fraction as F
from pathlib import Path
import json
# Coordinates scaled by 8, represented in basis 1,sqrt(3),h,sqrt(3)*h.
Z=(0,0); U=(1,0)
roots=[((2,0),Z),((0,1),U),(U,(0,1)),(Z,(2,0)),((-1,0),(0,1)),((0,-1),U)]
roots += [(tuple(-a for a in u),tuple(-a for a in v)) for u,v in roots]
A=(0,10,1,3,0,2,5,7,4,6,6,8,11,9)
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sc(k,a):return tuple(k*x for x in a)
def sub(a,b):return add(a,sc(-1,b))
V=(Z,Z); pts={}
for i,a in enumerate(A):
    u,v=roots[a]; x,y=V
    pts[i,0]=(sc(4,x)+(0,0),sc(4,y)+(0,0))
    pts[i,1]=(add(sc(4,x),u)+sc(-4,v),add(sc(4,y),v)+sc(4,u))
    pts[i,3]=(add(sc(4,x),sc(3,u))+sc(4,v),add(sc(4,y),sc(3,v))+sc(-4,u))
    V=(add(x,u),add(y,v))
assert V==(Z,Z) and len(set(pts.values()))==42
# Exact rational interval bounds; operations use all endpoints.
r=(F(1732050807568,10**12),F(1732050807570,10**12));h=(F(135,1000),F(136,1000))
assert r[0]**2<3<r[1]**2
def Iadd(a,b):return a[0]+b[0],a[1]+b[1]
def Isc(k,a):return min(k*a[0],k*a[1]),max(k*a[0],k*a[1])
def Imul(a,b):
    z=[x*y for x in a for y in b];return min(z),max(z)
def Isub(a,b):return Iadd(a,Isc(-1,b))
def evalp(a):
    out=(F(0),F(0))
    for k,b in zip(a,[(F(1),F(1)),r,h,Imul(r,h)]):out=Iadd(out,Isc(k,b))
    return out
def cross(p,q,s):
    a,b=(evalp(sub(x,y)) for x,y in zip(q,p));c,d=(evalp(sub(x,y)) for x,y in zip(s,p))
    return Isub(Imul(a,d),Imul(b,c))
H=[(12,0),(0,0),(2,0),(2,3),(5,0),(5,3),(6,0),(6,3),(9,0),(9,3),(10,3),(11,0),(11,3)]
minimum=None; count=0
for i,j in zip(H,H[1:]+H[:1]):
    for k,point in pts.items():
        if k in (i,j):continue
        lo,hi=cross(pts[i],pts[j],point)
        assert lo>0,(i,j,k,lo,hi)
        minimum=lo if minimum is None else min(minimum,lo);count+=1
assert count==13*40
lengths=[]
for i,j in zip(H,H[1:]+H[:1]):
    a,b=(evalp(sub(x,y)) for x,y in zip(pts[i],pts[j]))
    lengths.append(Isc(F(1,64),Iadd(Imul(a,a),Imul(b,b))))
assert lengths[9]==(F(1),F(1))
assert all(hi<1 or lo>1 for k,(lo,hi) in enumerate(lengths) if k!=9)
assert lengths[8][0]>lengths[10][1]
assert lengths[8][0]>F(58,100) and lengths[10][1]<F(82,1000)
out={'unique_unit_edge_index':9,'adjacent_squared_length_intervals':[[str(a) for a in lengths[k]] for k in (8,10)],'hull_vertices':H,'vertex_count':len(H),'support_inequalities':count,'min_scaled_cross_lower':str(minimum),'h_interval':[str(a) for a in h]}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
