#!/usr/bin/env python3
"""Independent finite checks supporting the B-adic lemma (not the general proof)."""
from fractions import Fraction as F
from collections import Counter
from itertools import product, combinations
from math import gcd
import json
from pathlib import Path
E=(0,1,-1,0,0,-1,1,0)
D=[]; prefix=Counter()
for e in E:
    D.append(dict(prefix)); prefix[e]+=1
assert dict(prefix)=={0:4,1:2,-1:2}
C=[{k-e:v for k,v in d.items()} for e,d in zip(E,D)]
C2=[{k for k,v in c.items() if v%2} for c in C]
assert C2==[set(),{-1},{1,2},{-1,0,1},{-1,1},{0,1,2},{-1,0},{0}]
assert len({frozenset(x) for x in C2})==8
# X(C_i-C_j) in F2[X]. Each degree <= 3 and nonzero.
diffs=[sum(1<<(k+1) for k in C2[i]^C2[j]) for i,j in combinations(range(8),2)]
assert all(0<d<16 for d in diffs)
def divmod2(a,b):
    assert b; q=0
    while a and a.bit_length()>=b.bit_length():
        k=a.bit_length()-b.bit_length();q^=1<<k;a^=b<<k
    return q,a
# Derive each cyclotomic polynomial modulo 2 recursively from X^m-1.
phi={}; classes={}; checked=0
for m in range(1,513):
    p=(1<<m)|1
    for d in range(1,m):
        if m%d==0:
            p,r=divmod2(p,phi[d]);assert r==0
    phi[m]=p
    deg=sum(gcd(m,k)==1 for k in range(1,m+1));assert p.bit_length()-1==deg
    masks=[sum(1<<(k+1) for k in c) for c in C2]
    distinct=len({divmod2(v,p)[1] for v in masks})
    if deg>3:
        assert all(divmod2(v,p)[1] for v in diffs)
        assert distinct==8;checked+=28
    else:classes[m]=distinct
assert set(classes)=={1,2,3,4,6}
# Check the last-mismatch leading coefficient in a formal Laurent ring in q,
# for all distinct words of each length 1, 2, 3. Keep B independent here.
wordpairs={}
def shift(c,h):return {k+h:v for k,v in c.items()}
def sub(c,d):
    r=c.copy()
    for k,v in d.items():r[k]=r.get(k,0)-v
    return {k:v for k,v in r.items() if v}
for n in range(1,4):
    enc=[]
    for w in product(range(8),repeat=n):
        a=0; coeff=[]
        for j in w:
            coeff.append(shift(D[j],a));a+=E[j]
        enc.append((w,a,coeff))
    c=0
    for (w,a,A),(v,b,V) in combinations(enc,2):
        m=max(k for k in range(n) if w[k]!=v[k]);r=a-b
        assert all(not sub(A[k],shift(V[k],r)) for k in range(m+1,n))
        d=sub(A[m],shift(V[m],r));prefix=sum(E[j] for j in w[:m+1])
        assert d==shift(sub(C[w[m]],C[v[m]]),prefix)
        assert any(z%2 for z in d.values());c+=1
    wordpairs[n]=c
# Explicit angle with power-of-two order within the certified interval.
k=21; m=1<<k; a=332049
assert gcd(a,m)==1
err=F(44,7)*abs(F(a,m)-F(19,120)) # strict since pi<22/7
assert err<F(1,10**6)
# Phi_(2^k)(X)=X^(2^(k-1))+1, hence Phi(-1)=2: 1+q not a unit.
assert (-1)**(1<<(k-1))+1==2
out={'residues_mod2':[sorted(c) for c in C2], 'distinct_pair_polynomials_mod2':sorted(set(diffs)), 'orders_tested':512,'pair_checks_phi_degree_gt3':checked,'exceptional_orders_distinct_residues':classes,'formal_word_pair_checks':wordpairs,'dyadic_order':m,'dyadic_numerator':a,'strict_angle_error_rational_upper':str(err)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
