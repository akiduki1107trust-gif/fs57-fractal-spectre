#!/usr/bin/env python3
"""Independent integer approximation with a priori rational error, and Laurent sign certificates.
Uniform over |theta-19*pi/60|<=10^-6 in radians. No old modules imported.
"""
from fractions import Fraction as F
from math import factorial
from itertools import combinations
from collections import Counter
import json
from pathlib import Path
Q=10**9; delta=F(1,10**6)
a,b,c=544639035,838670568,161850111
E=(0,1,-1,0,0,-1,1,0)
# Independently bound q at theta0 using alternating series.
def alt_atan(d,n):
    x=F(1,d); r=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(n)),F(0)); t=x**(2*n+1)/(2*n+1)
    return min(r,r+(-1)**n*t),max(r,r+(-1)**n*t)
p,r=alt_atan(5,16),alt_atan(239,6)
lo,hi=F(19,60)*(16*p[0]-4*r[1]),F(19,60)*(16*p[1]-4*r[0]);assert 0<lo<hi<1
C=lambda x,n:sum(((-1)**j*x**(2*j)/factorial(2*j) for j in range(n)),F(0))
S=lambda x,n:sum(((-1)**j*x**(2*j+1)/factorial(2*j+1) for j in range(n)),F(0))
cl,ch=C(hi,8),C(lo,9);sl,sh=S(lo,8),S(hi,9)
assert F(a-1,Q)<cl<ch<F(a+1,Q)
assert F(b-1,Q)<sl<sh<F(b+1,Q)
assert F(c-1,Q)<1/(4*(1+ch))<1/(4*(1+cl))<F(c+1,Q)
cl-=delta;ch+=delta;sl-=delta;sh+=delta
slo,shi=1/(4*(1+ch)),1/(4*(1+cl))
assert F(27,50)<cl<ch<F(3,5) and F(27,200)<slo*sl<shi*sh<F(17,125)
assert shi<F(25,154) and 8*shi**2<1 and 8*slo>1
assert 2*(1-ch)>4*shi**2
# Unit diameter, endpoint cones and uniform disk radius of G.
hlo,hhi=F(27,200),F(17,125)
assert F(1,4)+4*hhi*hhi<1 and F(9,16)+hhi*hhi<1
assert 3*(4*hhi)**2<1 and 2*hhi<F(1,2)
assert (hlo/2)**2>F(1,12)**2*(F(3,4)**2+hhi*hhi)
# Laurent residues of degree span three; exact Phi120(-1)=1 as required.
phi={32:1,28:1,20:-1,16:-1,12:-1,4:1,0:1}
assert sum(v*(-1)**k for k,v in phi.items())==1
# complex integers. All approximated grid locations are EXACT rationals.
def add(x,y):return x[0]+y[0],x[1]+y[1]
def neg(x):return -x[0],-x[1]
def sub(x,y):return add(x,neg(y))
def mul(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def times(k,x):return k*x[0],k*x[1]
def conj(x):return x[0],-x[1]
def norm2(x):return x[0]**2+x[1]**2
qh={1:(a,b),-1:(a,-b),0:(Q,0)}
assert norm2(qh[1])<(Q+2)**2 and c*(Q+2)*5<Q*Q
# D_j and B; use exact Laurent-polynomial operations in formal variable X=q.
def lp(*terms):return {i:v for i,v in Counter(dict(terms)).items() if v}
def padd(x,y):
    z=x.copy()
    for k,v in y.items():z[k]=z.get(k,0)+v
    return {k:v for k,v in z.items() if v}
def pneg(x):return {k:-v for k,v in x.items()}
def psub(x,y):return padd(x,pneg(y))
def pmul(x,y):
    z={}
    for i,a0 in x.items():
        for j,b0 in y.items():z[i+j]=z.get(i+j,0)+a0*b0
    return {k:v for k,v in z.items() if v}
def pcj(x):return {-k:v for k,v in x.items()}
def mon(i):return {i:1}
B={0:4,1:2,-1:2}; H={0:1,1:1}; hull=[{},H,B,psub(B,H)]
BH=[pmul(B,g) for g in hull]; prefix={}; cells=[]; residue=[]
for e in E:
    residue.append(tuple(sorted((i,v%2) for i,v in pmul(mon(-e),prefix).items() if v%2)))
    cells.append([padd(pmul(B,prefix),pmul(mon(e),g)) for g in hull])
    prefix=padd(prefix,mon(e))
assert prefix==B and len(set(residue))==8
power={0:(1,0)}
for k in range(1,5):power[k]=mul(power[k-1],qh[1]);power[-k]=conj(power[k])
# Error |q-qhat|<=delta+2/Q; for |k|<=4, <=5*(delta+2/Q).
eq=delta+F(2,Q); assert 4*(1+eq)**3<5
count=Counter(); smallest=None
def sign_im(p):
    global smallest
    assert all(abs(k)<=4 for k in p)
    if p==pcj(p):count['identical_zero']+=1;return 0
    val=sum(v*power[k][1]*Q**(4-abs(k)) for k,v in p.items())
    err=5*eq*sum(map(abs,p.values()))
    assert F(abs(val),Q**4)>err,(p,val,err)
    marge=F(abs(val),Q**4)-err
    smallest=marge if smallest is None else min(smallest,marge)
    count['strict_sign']+=1;return 1 if val>0 else -1
def cross(a0,b0,p):return sign_im(pmul(pcj(psub(b0,a0)),psub(p,a0)))
for g in cells:
    for p0 in g:
        for i in range(4):assert cross(BH[i],BH[(i+1)%4],p0)<=0
assert sign_im(pmul(pcj(psub(BH[1],BH[0])),psub(BH[2],BH[0])))==-1
chosen=[]
for i,j in combinations(range(8),2):
    opts=[]
    for x,y in ((i,j),(j,i)):
        for k in range(4):
            ss=[cross(cells[x][k],cells[x][(k+1)%4],p0) for p0 in cells[y]]
            if min(ss)>=0 and max(ss)>0:opts.append((ss.count(0),x,y,k))
    assert opts; z=min(opts)
    assert z[0]==(0 if j-i>1 else (2 if (i,j)==(3,4) else 1)),(i,j,z)
    chosen.append([i,j,list(z)])
# endpoint uniqueness (positive real step, first/last uniquely attain G extremes)
assert E[0]==E[-1]==E[3]==E[4]==0 and E==E[::-1]
# exact rational grid recursion, common denominator (Q^2)^4
step=Q**2; A=[times(c,qh[e]) for e in E]; P=[(0,0)]
for z in A:P.append(add(P[-1],z))
G=[(0,0),(1,0)];den=1
for n in range(1,5):
    G=[add(times(den,P[j]),mul(A[j],z)) for j in range(8) for z in G[:-1]]+[(den*step,0)]
    den*=step
assert len(G)==4097;D=den;N=4096
# |s-s_hat|<=delta/4+1/Q, |a_j-a_hat_j|<delta/2+3/Q
# recurrence: g error <=8*eps+(1/5) error_prev => <=10*eps.
eps=delta/2+F(3,Q); eg=10*eps; ez=eq+2*eg; er=4*ez+3*eg
assert 2+2*ez<3
# Grid residual exact at approximate constants; all Rhat have denom Q*D^2.
res={}; trials=(128,1024,2048)
for mode,cut,st,first,last in [('mirror',F(249,10000),1,0,N),('direct',F(77,1000),8,512,3584)]:
    minr=None; total=0; rden=Q*D*D
    for j in range(7):
        u,v=qh[E[j]],qh[E[j+1]]
        for k in range(first,last+1,st):
            w0=mul(u,sub(G[k],(D,0)))
            d0=add(times(D,u),mul(sub(v,u),G[k]))
            best=0
            for t in trials:
                z=mul(u,sub(G[k+t],(D,0))) if k+t<=N else mul(v,G[k+t-N])
                gt=conj(G[t]) if mode=='mirror' else G[t]
                rr=sub(times(D,sub(z,w0)),mul(d0,gt));best=max(best,norm2(rr))
            assert best*cut.denominator**2>rden*rden*cut.numerator**2,(mode,j,k)
            minr=best if minr is None else min(minr,best);total+=1
    uniform=F(19,1000) if mode=='mirror' else F(21,500)
    k=4 if mode=='mirror' else 3
    assert cut-er-8*shi**k>uniform
    res[mode]={'points':total,'grid_norm_strict_lower':str(cut),'uniform_true_norm_strict_lower':str(uniform),'min_approx_squared':str(F(minr,rden*rden))}
# integer angle stars are stable in a small neighborhood; any 6 angles exceed 360.
# parameter affine labels (a,b) -> a+b*theta in degrees.
labels=[(90,0),(120,0),(180,0),(240,0),(270,0),(180,-2),(180,-1),(180,1),(180,2)]
stars=[];near=[]
for n in range(1,6):
    from itertools import combinations_with_replacement
    for ix in combinations_with_replacement(range(9),n):
        aa=sum(labels[i][0] for i in ix);bb=sum(labels[i][1] for i in ix)
        diff=aa+57*bb-360
        if diff==0:
            assert bb==0;stars.append(ix)
        else:assert F(abs(diff))>abs(bb)*60*delta # deg drift <=60*delta (pi>3)
        near.append(ix)
assert len(stars)==8 and len(near)==2001 # number all multisets size 1..5 = C(14,5)-1
# 6 angles suffices impossible: minimum >=66-2*60delta >60.
assert F(66)-120*delta>60
# phi120 mod2(X) has degree 32 and constant1, so multiplying any residue diff by X^1.. etc (<32) cannot be zero.
assert max(k for r in residue for k,v in r)-min(k for r in residue for k,v in r)<32
out={'delta_rad':str(delta),'qhat':[a,b,Q],'shat':[c,Q], 'geometry_counts':dict(count),'smallest_certified_imaginary_margin_approx':float(smallest),'separators':chosen,'residues':residue,'residual_error_rational':str(er),'grid':res,'angle_multisets_tested':len(near),'angle_stars':len(stars)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',out['geometry_counts'], 'grid', {k:v['points'] for k,v in res.items()},'angles',len(near),'error',er,'min geom margin',float(smallest))
