#!/usr/bin/env python3
"""Macro polygon in Z[sqrt(3)]/2; independent integer checks."""
from itertools import combinations
from pathlib import Path
import json
Z=(0,0); U=(1,0)
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sc(k,a):return k*a[0],k*a[1]
def neg(a):return sc(-1,a)
def sub(a,b):return add(a,neg(b))
def mul(a,b):return a[0]*b[0]+3*a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def sig(a):
    x,y=a
    if x==0:return (y>0)-(y<0)
    if y==0:return (x>0)-(x<0)
    if x*y>0:return 1 if x>0 else -1
    assert x*x!=3*y*y
    return (1 if x>0 else -1)*(1 if x*x>3*y*y else -1)
def va(a,b):return add(a[0],b[0]),add(a[1],b[1])
def vs(a,b):return sub(a[0],b[0]),sub(a[1],b[1])
def dot(a,b):return add(mul(a[0],b[0]),mul(a[1],b[1]))
def cross(a,b):return sub(mul(a[0],b[1]),mul(a[1],b[0]))
# 2*coordinates of each unit root. Construct second half by exact negation.
roots=[((2,0),Z),((0,1),U),(U,(0,1)),(Z,(2,0)),((-1,0),(0,1)),((0,-1),U)]
roots += [(neg(x),neg(y)) for x,y in roots]
A=(0,10,1,3,0,2,5,7,4,6,6,8,11,9)
V=[(Z,Z)]
for i in A:V.append(va(V[-1],roots[i]));assert dot(roots[i],roots[i])==(4,0)
assert V[-1]==V[0];V.pop()
# Transcribed exact coordinate list of the independent code at
# https://raw.githubusercontent.com/shrx/spectre/master/spectre.py lines 46–61.
ref=[(Z,Z),((2,0),Z),((3,0),(0,-1)),((3,1),(1,-1)),((3,1),(3,-1)),((5,1),(3,-1)),((6,1),(3,0)),((6,0),(4,0)),((6,-1),(3,0)),((5,-1),(3,1)),((3,-1),(3,1)),((1,-1),(3,1)),((0,-1),(3,0)),(Z,(2,0))]
assert V==ref
area=(0,0)
for i in range(14):area=add(area,cross(V[i],V[(i+1)%14]))
assert area==(24,24) # division by 8 -> 3+3sqrt3
# Endpoint/segment distance >1/2, exact squared inequality.
def far(P,A,B):
    E=vs(B,A);W=vs(P,A);t=dot(E,W);n=dot(W,W)
    if sig(t)<=0:return sig(sub(n,U))>0
    if sig(sub(t,(4,0)))>=0:return sig(sub(dot(vs(P,B),vs(P,B)),U))>0
    return sig(sub(sub(sc(4,n),mul(t,t)),(4,0)))>0
pairs=0
for i,j in combinations(range(14),2):
    if j==i+1 or (i,j)==(0,13):continue
    a,b,c,d=V[i],V[(i+1)%14],V[j],V[(j+1)%14]
    test=lambda p,q,r:sig(cross(vs(q,p),vs(r,p)))
    assert not (test(a,b,c)*test(a,b,d)<0 and test(c,d,a)*test(c,d,b)<0)
    assert far(a,c,d) and far(b,c,d) and far(c,a,b) and far(d,a,b)
    pairs+=1
assert pairs==77
turn=lambda t:(t+180)%360-180
T=[turn(30*(A[(j+1)%14]-A[j])) for j in range(14)]
assert set(T)=={-90,-60,0,60,90} and sum(T)==360 and T.count(0)==1
r=T.index(0);assert any(T[(r+j)%14]!=T[(r-j)%14] for j in range(14))
# Distinct macro reverse contact poses: orientation r, translation t (twice coords).
def rot(p,k):
    x,y=p;u,v=roots[k%12];a=sub(mul(u,x),mul(v,y));b=add(mul(v,x),mul(u,y))
    assert all(z%2==0 for z in a+b)
    return tuple(z//2 for z in a),tuple(z//2 for z in b)
poses={}
for i in range(14):
    for j in range(14):
        r=(A[i]-A[j]+6)%12
        t=vs(V[(i+1)%14],rot(V[j],r))
        assert va(t,rot(V[(j+1)%14],r))==V[i]
        poses.setdefault((r,t),[]).append((i,j))
out={'direction_sequence':A,'nonadjacent_pairs':pairs,'area':'3+3sqrt(3)','unique_straight_vertex':True,'reverse_angle_word_asymmetric':True,'source_coordinate_match':True,'formal_macro_contact_labels':196,'distinct_macro_contact_poses':len(poses),'multiplicities':{str(k):sum(len(v)==k for v in poses.values()) for k in sorted({len(v) for v in poses.values()})}}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',out)
