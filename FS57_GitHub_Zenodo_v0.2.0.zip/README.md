# FS57: A Fractal-Boundary Deformation of the Spectre Tile

*A computer-assisted proof candidate for forced aperiodicity*

**Shigehisa Harada — Independent Researcher** | Preprint v0.2.0 | 2026-11-21 | CP-FS57-722

[Preprint (PDF)](paper/FS57.pdf) · [Japanese summary](README_JA.md) · [Reproduction](REPRODUCE.md)

We study a specific fourteen-edge deformation of the marked equilateral polygon Tile(1,1) using an eight-branch self-similar Jordan arc at 57 degrees, of Hausdorff dimension approximately 1.14187. We present an internally audited computer-assisted proof candidate for strong aperiodicity, including when reflected copies are permitted. The proposed reduction combines rigorous finite geometric and residual certificates, natural Hausdorff-measure parametrization, B-adic alignment, local winding-number cancellation, and a four-child angle-word descent to establish placement-preserving equivalence with homochiral Tile(1,1) tilings. The published Spectre theorem supplies the final existence and aperiodicity result if the reduction is valid. Four certificate scripts and byte-matching reference outputs are provided. The full proof has not been formally verified or independently refereed; no claim of priority is made.

![Eight-branch generator and finite approximation to the mathematical tile](figures/model.png)

The illustration is generated from the defined IFS and fourteen-edge direction word; it is not a proof of tiling existence. The original Spectre theorem is due to [Smith, Myers, Kaplan and Goodman-Strauss (2024)](https://doi.org/10.5070/C64264241). The proposed result concerns preservation of forced aperiodicity under a specified fractal deformation, not discovery of the Spectre itself.

## Reproduce

Python 3.13.5 (standard library, no network). From the repository root:

```bash
python code/verify.py
```

See `REPRODUCE.md` for the finite verification scope and LaTeX build instructions. Do not use `python -O`.

## Contents

| Path | Purpose |
|---|---|
| `paper/FS57.pdf`, `paper/FS57.tex` | English preprint and LaTeX source |
| `figures/` | Model-generated illustration |
| `code/`, `results/` | Four certificate scripts, exact reference JSON, replay wrapper and execution log |
| `metadata/` | Source provenance, Zenodo metadata, publication and licensing instructions |
| `CITATION.cff`, `.zenodo.json` | Citation and deposit configuration |
| `SHA256SUMS.txt` | Public package integrity manifest |

## Status and citation

Harada, S. (2026). *FS57: A Fractal-Boundary Deformation of the Spectre Tile: A computer-assisted proof candidate for forced aperiodicity*. v0.2.0. Preprint for independent review. DOI not yet assigned.

AI assistance was used for mathematical exploration, drafting and code verification. The author should approve the manuscript, distribution and licensing before publication. The finite checks do not replace independent mathematical review. No world-first claim is made. No external publication, DOI assignment or endorsement is implied.
