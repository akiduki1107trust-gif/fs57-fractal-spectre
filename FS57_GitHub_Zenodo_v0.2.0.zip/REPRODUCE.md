# Reproduction — v0.2.0

From the extracted repository root, using ordinary Python 3.13.5:

```sh
python code/verify.py
```

The wrapper verifies the eight immutable certificate/reference-file hashes in `metadata/CERTIFICATE_SHA256.txt`, runs each script in a fresh temporary directory, and compares the JSON byte for byte. Do not use `-O`. Only the standard library is needed. The source of each file is documented in `metadata/PROVENANCE.md`. The check establishes the finite predicates, not the complete analytic proof. The published Spectre theorem is an external input.

Rebuild the manuscript with TeX Live:

```sh
cd paper
pdflatex -interaction=nonstopmode -halt-on-error FS57.tex
pdflatex -interaction=nonstopmode -halt-on-error FS57.tex
```

Optional figure regeneration: install matplotlib and run `python code/draw_model.py` from the repository root. Figures are numerical illustrations, not certificates. Figure regeneration may change PDF metadata or PNG bytes. A release integrity check is `sha256sum -c SHA256SUMS.txt` (before modifying files).
